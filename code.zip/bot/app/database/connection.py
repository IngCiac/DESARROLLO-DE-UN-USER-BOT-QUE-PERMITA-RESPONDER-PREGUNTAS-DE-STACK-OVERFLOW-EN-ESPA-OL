import os
import sqlalchemy
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

connection: str = 'mssql+pyodbc://{username}:{password}@{hostname}:{port}/{database}?driver={driver}'.format(
    username = os.getenv('DATABASE_USERNAME'),
    password = os.getenv('DATABASE_PASSWORD'),
    hostname = os.getenv('DATABASE_HOSTNAME'),
    port = os.getenv('DATABASE_PORT'),
    database = os.getenv('DATABASE_NAME'),
    driver = 'ODBC Driver 17 for SQL Server'
)

engine = sqlalchemy.create_engine(connection)
#engine = sqlalchemy.create_engine('sqlite:///database/database.sqlite3')

Session = sessionmaker(
    bind = engine
)
Base = declarative_base()
session = Session()
